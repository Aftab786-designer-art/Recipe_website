<?php
defined( 'ABSPATH' ) || die( 'Cheatin’ uh?' );

?>
<h1><?php esc_html_e( 'Other Media optimized by Imagify', 'imagify' ); ?></h1>
<?php
