import * as chart from 'chart.js/auto'

window.imagify = window.imagify || {};

window.imagify.Color = chart.Colors;
window.imagify.Chart = chart.Chart;
